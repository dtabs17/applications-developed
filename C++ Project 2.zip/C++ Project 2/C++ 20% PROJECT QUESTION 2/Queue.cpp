using namespace std;
#include <iostream>
#include "Queue.h"

struct NodeType {
    string info;
    NodeType* next;
};

QueType::QueType() {
    qFront = NULL;
    qRear = NULL;
}

void QueType::MakeEmpty() {
    NodeType* tempPtr;
    while (qFront != NULL) {
        tempPtr = qFront;
        qFront = qFront->next;
        delete tempPtr;
    }
    qRear = NULL;
}

void QueType::Enqueue(string& newItem) {
    NodeType* newNode;
    newNode = new NodeType;
    newNode->info = newItem;
    newNode->next = NULL;
    if (qRear == NULL)
        qFront = newNode;
    else
        qRear->next = newNode;
    qRear = newNode;
}

void QueType::Dequeue(string& item) {
    NodeType* tempPtr;
    while (qFront->next != NULL)
    {
        if (item != qFront->info) 
        {
            tempPtr = qFront;
            qFront = qFront->next;
            tempPtr = nullptr;
        }
        else 
        {
            tempPtr = qFront;
            qFront = qFront->next;
            tempPtr = nullptr;
            break;
        }
    }
    if (qFront == NULL)
        qRear = NULL;
}

void QueType::PrintQueue() const {

    NodeType* tempPtr = qFront;

    cout << "Queue: ";
    while (tempPtr != NULL) {
        cout << tempPtr->info << " ";
        tempPtr = tempPtr->next;
    }
    cout << endl;
}

void QueType::ReverseQueue() {
    NodeType* current = qFront;
    NodeType* prev = nullptr;
    NodeType* next = nullptr;

    while (current != nullptr) {
        next = current->next;
        current->next = prev;
        prev = current;
        current = next;
    }

    qFront = prev;
}

void QueType::Search(string item) {
    bool moreToSearch;
    NodeType* location;
    location = qFront;
    bool found = false;
    moreToSearch = (location != NULL);
    while (moreToSearch && !found) {
        if (item == location->info) {
            found = true;
            cout << "'" << item << "'" << " has been found in the queue." << endl;
            break;
        }
        else 
        {
            location = location->next;
            moreToSearch = (location != NULL);
        }
    }
    if (!found)
    {
        cout << "'" << item << "'" << " was not found in the queue." << endl;
    }
}