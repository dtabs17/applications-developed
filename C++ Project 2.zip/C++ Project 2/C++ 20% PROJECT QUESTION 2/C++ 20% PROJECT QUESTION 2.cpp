#include <iostream>
#include "Queue.h"
using namespace std;
int menu();
void AddData(QueType& qt);
void remove(QueType& qt);
void searching(QueType qt);

int main()
{
    int option;
    QueType Q1;
    do
    {
        option = menu();
        switch (option)
        {
        case 1:
            AddData(Q1);
            break;
        case 2:
            Q1.MakeEmpty();
            break;
        case 3:
            remove(Q1);
            break;
        case 4:
            Q1.PrintQueue();
            break;
        case 5:
            Q1.ReverseQueue();
            break;
        case 6:
            searching(Q1);
            break;
        case 7:
            break;
        default:
            cout << "Invalid Option! Please select an option between 1 and 7." << endl;
            break;
        }
    } while (option != 7);
    cout << "Thank you for using the program! Goodbye!" << endl;
}

int menu()
{
    int input;
    cout << "Please enter the option you would like to implement" << endl;
    cout << "Option 1. Add data to the queue." << endl;
    cout << "Option 2. Clear all the contents of the queue." << endl;
    cout << "Option 3. Remove 1 item from the queue." << endl;
    cout << "Option 4. Print contents of the queue." << endl;
    cout << "Option 5. Reverse the data inside the queue." << endl;
    cout << "Option 6. Search for a string within the queue." << endl;
    cout << "Option 7. Exit" << endl;
    cin >> input;
    return input;
}

void AddData(QueType& qt)
{
    string item;
    cout << "Please enter the item you wold like in the list: " << endl;
    cin >> item;
    qt.Enqueue(item);
}

void remove(QueType& qt)
{
    string item;
    cout << "Please enter the item you would like to remove: " << endl;
    cin >> item;
    qt.Dequeue(item);
    cout << "The updated queue with " << item << " removed is: " << endl;
    qt.PrintQueue();
}

void searching(QueType qt)
{
    string item;
    cout << "Please enter the item you would like to search for " << endl;
    cin >> item;
    qt.Search(item);
}