#pragma once
struct NodeType;
using namespace std;

class QueType {
public:
    QueType();

    void MakeEmpty();

    void Enqueue(string& newItem);

    void Dequeue(string& item);

    void PrintQueue() const;

    void ReverseQueue();

    void Search(string item);
private:
    NodeType* qFront;
    NodeType* qRear;
};